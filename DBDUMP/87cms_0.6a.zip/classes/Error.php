<?php

class Error {
	
	public static function show($str){
		var_dump($str);
	}
	
}