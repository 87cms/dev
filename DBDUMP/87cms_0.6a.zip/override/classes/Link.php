<?php

class Link extends LinkCore {
	
	
}