<?php

$content = '
<h3>About Initializr</h3>
<p>Initializr is here to kick-start the development of your new projects. It generates templates based on HTML5 Boilerplate by allowing you to choose which parts you want or don\'t want from it. A <a href="http://verekia.com/initializr/responsive-template" target="_blank">responsive template</a>has also been added to start from a basic design instead of a blank page.</p>
<h3>International guides</h3>
<p>Initializr functioning is pretty intuitive but it can help to read guides about it in your own language. Here are some which will help you using Initializr and understanding HTML5 Boilerplate, HTML5shiv or Modernizr, in<a href="http://www.html5-css3.fr/html5/initializr-generateur-template-html5-boilerplate" target="_blank">French</a>, <a href="http://www.cuble.es/blog/manual-de-initializr/" target="_blank">Spanish</a>, <a target="_blank" href="http://simonebertuccioli.it/archives/initializr/">Italian</a>, 

{$DISPLAY_SIDEBAR}

<a href="http://starwebdesign.com.ua/blog/2011/02/16/initializr-generator-chistogo-i-nastraivaemogo-html5-shablona-osnovannogo-na-boilerplate/" target="_blank">Russian</a>, <a href="http://www.jaapvdveen.nl/2011/02/17/initializr-een-template-generator-op-basis-van-html5-boilerplate/" target="_blank">Dutch</a>, <a href="http://flaviosilveira.com/2011/initializr-comece-seu-projeto-html5-em-15-segundos/" target="_blank">Portuguese</a>, <a href="http://www.blueweb.sk/blog/2012/12/08/initializr-starter-vasich-projektov">Slovak</a>, <a href="http://blog.plainly.co/post/38219874004/initializr-polish-guide" target="_blank">Polish</a>,<a href="http://www.fantades.com/initializr-templates-generator-based-on-html5boilerplate/" target="_blank">Arabic</a>, and <a href="http://blog.imho.jp/p/blog-page.html" target="_blank">Japanese</a>.</p>';

var_dump( preg_match('/\{\$DISPLAY_SIDEBAR\}/', $content ));
