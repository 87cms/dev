<?php

class AttributeValueCore extends Core {

	protected $table = 'attribute_value';	
	protected $identifier = 'id_attribute_value';
	
	public $id_attribute_value;
	public $id_attribute;
	public $name;
	
	
	public function delete(){
		Db::getInstance()->Delete('attribute_value_lang', array('id_attribute_value' => $this->id_attribute_value));
		Db::getInstance()->Delete('attribute_value', array('id_attribute_value' => $this->id_attribute_value));	
	}
	
}

