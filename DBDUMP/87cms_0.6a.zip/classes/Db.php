<?php

class Db extends Core {
	
	protected static $sql;
	
	public static function getInstance(){
		if( !isset(self::$sql) )
			self::$sql = new MySQL();
		return self::$sql;
	}	
	
}

?>