<?php

class Attribute extends AttributeCore {

}