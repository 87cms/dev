<?php

class EntityModelController extends EntityModelControllerCore {
	
}