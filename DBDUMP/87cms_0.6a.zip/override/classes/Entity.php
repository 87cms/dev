<?php

class Entity extends EntityCore {

}

