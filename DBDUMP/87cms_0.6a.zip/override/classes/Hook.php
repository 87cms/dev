<?php

class Hook extends HookCore {
	
	
}