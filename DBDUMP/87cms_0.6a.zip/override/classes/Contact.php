<?php

class Contact extends ContactCore {
	
}