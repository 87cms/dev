<?php
/*
 * jQuery File Upload Plugin PHP Example 5.14
 * https://github.com/blueimp/jQuery-File-Upload
 *
 * Copyright 2010, Sebastian Tschan
 * https://blueimp.net
 *
 * Licensed under the MIT license:
 * http://www.opensource.org/licenses/MIT
 */
session_start();
define("SQL_DEBUG", true);
require_once('../config/constant.php');
require_once('../config/db_settings.php');
require_once('../classes/Error.php');

require_once('../classes/Tools.php');
require_once('../classes/Core.php');
require_once('../classes/Cookie.php');
require_once('../classes/Db.php');
require_once('../classes/Mysql.php');
require_once('../classes/Lang.php');

require_once('../classes/Mediabox.php');
require_once('../classes/MediaboxDir.php');
require_once('../classes/MediaboxFile.php');

require_once('../classes/Upload.php');

$upload_handler = new UploadHandler();
session_write_close();