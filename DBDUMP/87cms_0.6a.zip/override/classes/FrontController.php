<?php

class FrontController extends FrontControllerCore {
	
	

}
