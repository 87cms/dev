<?php /* Smarty version Smarty-3.1.11, created on 2013-09-09 17:10:40
         compiled from "template/head.html" */ ?>
<?php /*%%SmartyHeaderCode:1184963582522de4f0c1e653-33756516%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7843bb47914859ae38ab5fa3287bacfdc5c070fc' => 
    array (
      0 => 'template/head.html',
      1 => 1378389700,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1184963582522de4f0c1e653-33756516',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'languages' => 0,
    'key' => 0,
    'value' => 0,
    'LANG' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.11',
  'unifunc' => 'content_522de4f0ca7067_98329679',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_522de4f0ca7067_98329679')) {function content_522de4f0ca7067_98329679($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Administration</title>

<link href='http://fonts.googleapis.com/css?family=Lato:300' rel='stylesheet' type='text/css'>
<link href="template/style.css" rel="stylesheet" type="text/css" />

<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>

<script type="text/javascript" src="js/main.js"></script>
<script type="text/javascript" src="/js/tools.js"></script>


<script type="text/javascript" src="js/multilang.js"></script>
<script type="text/javascript" src="js/lang/en.js"></script>
<script type="text/javascript">
	var languages = new Array();
	<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['value']->_loop = false;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
$_smarty_tpl->tpl_vars['value']->_loop = true;
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
		languages[<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
] = { 
			id_lang : '<?php echo $_smarty_tpl->tpl_vars['value']->value['id_lang'];?>
',
			code : '<?php echo $_smarty_tpl->tpl_vars['value']->value['code'];?>
'
		};			
	<?php } ?>
	
	var _LANG_ = "<?php echo $_smarty_tpl->tpl_vars['LANG']->value;?>
";
	
	$(document).ready(function(e) {
        //$('.multilang').MultilangInput();
		resizeContent();		
    });
	$(window).resize( resizeContent );
	
	function resizeContent(){
		/*var w = $(window).width() -  230 - 100 ;
		$('#content').css('width', w);
		
		var h = $(window).height();
		var hc = $('#content').height();
		var hs = $('#sidebar').height();
		if( hc > hs )
			$('#sidebar').height( hc+100 );*/
		$('#front_header').width( $(window).innerWidth() - 230 );
	}
	
</script>


</head>

<body>

<?php }} ?>