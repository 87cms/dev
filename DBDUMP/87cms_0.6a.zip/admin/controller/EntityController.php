<?php


class EntityController extends AdminController {
	
	
	
	public function run(User $user){
		
		$this->user = $user;
		
		$this->action = Tools::getSuperglobal('action');
		if( isset($this->action) && !empty($this->action) ){
			
			if( $this->action == "form" )
				$this->displayForm( (int)Tools::getSuperglobal('id_entity_model') );
			
			if( $this->action == "submitEntity")
				$this->addEntity();
			
			if( $this->action == "deleteEntity")
				$this->deleteEntity(Tools::getSuperglobal('id_entity'));
			
		}else{
			
			$model = new EntityModel(Tools::getSuperglobal('id_entity_model'));
			$fields = array_slice($model->getFieldsList($this->cookie->id_lang), 0, 5);
			
			if( !$model->hierarchic ){			
				$parents = $model->getHierarchicTree(0, $this->cookie->id_lang);
				
				$parent_model = new EntityModel( $model->id_parent );
			}
			
			$this->smarty->assign(array(
				'parents' => $parents,
				'parent_name' => $parent_model->lang[$this->cookie->id_lang]['name'],
				'id_parent' => (int)Tools::getValue('id_parent'),
				'hierarchic' => $model->hierarchic,
				'modelname' => $model->lang[$this->cookie->id_lang]['name'],
				'id_entity_model' => (int)Tools::getSuperglobal('id_entity_model')
			));
			
			$nbentities = 0;
			
			$user = false;
			$all_access = $this->user->userHasPermission( $model->id_entity_model, 0 ); 
			if( !$all_access && !$this->user->is_admin )
				$user = $this->user;
			else $user = NULL;
			
			if( $model->hierarchic ){
				
				$entities = Entity::getHierarchicEntitiesList(
					$model->id_entity_model, 
					$this->cookie->id_lang,
					0,
					0,
					0,
					0, 
					'', 
					true,
					$user
				);
				
				$nbentities = count($entities);
				
			}else{
				
				$entities = Entity::getEntitiesList(
					Tools::getSuperglobal('id_entity_model'), 
					$this->cookie->id_lang,
					Tools::getValue('id_parent'),
					Tools::getValue('sort'), 
					Tools::getValue('page'), 
					20,
					true,
					$user
				);
				
				$nbentities = Entity::countEntities(
					Tools::getSuperglobal('id_entity_model'), 
					$this->cookie->id_lang,
					Tools::getValue('id_parent'),
					Tools::getValue('sort'),
					true,
					$user
				);
			}

			$this->smarty->assign(array(
				'nbentities' => $nbentities,
				'item_per_page' => 20,
				'entities' => $entities,
				'model' => $model
			));
			
			$this->smarty->display('entity.html');
		
		}	
		
	}
	
	
	
	public function displayForm($id_entity_model=0){
		
		$model = new EntityModel($id_entity_model);
		
		if( $model ){
			
			$this->smarty->assign(array(
				'modelname' => $model->lang[$this->cookie->id_lang]['name'],
				'model' => $model,
				'id_entity_model' => (int)$id_entity_model
			));
			
			if( !$model->hierarchic && $model->id_parent ){
				$parents = $model->getHierarchicTree(0, $this->cookie->id_lang);
			}elseif( $model->hierarchic && !$model->id_parent ){
				$parents = $model->getHierarchicTree(0, $this->cookie->id_lang);
			}
			
			$fields = $model->getFieldsList($this->cookie->id_lang);
			
			foreach( $fields as &$field ){
				
				if( $field['type'] == 'select' ){
					$field['attributes'] = Attribute::getValues($field['params'][0]['value'], $this->cookie->id_lang);	
				}
				
				if( $field['type'] == "linkedEntities" ){
					$field['entities'] = Entity::getEntitiesList($field['params'][0]['value'], $this->cookie->id_lang, NULL, 'meta_title', 0, 10000, true);
				}
				
			}
			
			$this->initRichtext();
			
			$entity = NULL;
			
			if( Tools::getSuperGlobal('id_entity') > 0 ){
				$entity = new Entity( Tools::getSuperGlobal('id_entity') );
	
				if( $entity->id_entity <= 0 )
					return false;
				
				foreach( $fields as &$field ){
					$field['values'] = EntityField::getFieldValues( $field['id_field_model'], Tools::getSuperGlobal('id_entity') );
					$field['raw_value'] = EntityField::getRawValue( $field['id_field_model'], Tools::getSuperGlobal('id_entity') );
				}
				
			}
			
			$this->smarty->assign(array(
				'entity' => $entity,
				'fields' => $fields,
				'parents' => $parents
			));
			
			
			$all_access = $this->user->userHasPermission( $model->id_entity_model, 0 ); 
			if( !$all_access && !$this->user->is_admin ){
				$access = $this->user->userHasPermission( $model->id_entity_model, $entity->id_entity );
				if( !$access ) Tools::redirect('/admin/index.php');
			}			
			
			$this->smarty->display('entity_form.html');
		
		}
		
	}
	
	public function initRichtext(){
		// 1. get elements
		$elements = array();
		$dir = "js/richtext/elements";
		$dh  = opendir($dir);
		while (false !== ($filename = readdir($dh))) {
			
			if( is_dir($dir.'/'.$filename) ){
				$js = ( file_exists($dir.'/'.$filename.'/'.$filename.'.js') ? $dir.'/'.$filename.'/'.$filename.'.js' : false );
				$icon = ( file_exists($dir.'/'.$filename.'/'.$filename.'.png') ? $dir.'/'.$filename.'/'.$filename.'.png' : false );
				
				$lang_file = $dir.'/'.Lang::getLangCode($this->cookie->id_lang).'.php';
				$lang = ( file_exists($lang_file) ? require_once($lang_file) : false );;
				
				if( $js ) {
					$elements[] = array(
						'js' => $js,
						'icon' => $icon,
						'name' => $filename,
					);
				}
				
			}
		}
		$this->smarty->assign('elements', $elements);		
	}
	
	
	public function deleteEntity($id_entity){
		$entity = new Entity($id_entity);
		$entity->delete();
		
		Tools::redirect('/admin/index.php?p=entity&id_entity_model='.Tools::getSuperGlobal('id_entity_model'));
	}
	

}