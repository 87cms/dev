<?php

class ContactControllerCore extends FrontController {

	public function run(){

		$this->action = Tools::getSuperglobal('action');
		if( isset($this->action) && !empty($this->action) ){

			if( $this->action == "send")
				$this->sendMessage();

			else
				Tools::redirect('/'.Lang::getLangCode($this->cookie->id_lang).'/contact/');

		}

		$this->display();
	}
	
	public function sendMessage(){
		
		$contact = new Contact();
		$contact->from = '';
		$contact->to = '';
		$contact->subject = '';
		$contact->message = '';
		
			if($message->send()){
				Tools::redirect('/'.Lang::getLangCode($this->cookie->id_lang).'/contact/');
			}else{
				Tools::redirect('/'.Lang::getLangCode($this->cookie->id_lang).'/contact/error');
			}

	}

	/**
	* The classic display method
	*/
	public function display(){
		$this->sendTemplatesToSmarty("head.html, header.html, contact.html, 3points.html, footer.html");		
	}
	
	/**
	* Set SEO elements as meta elements, or canonical
	*/
	public function setSEO(){
		$sep = array(
			'meta_title' => 'Contact',
			'meta_description' => '',			
		);
		$this->smarty->assign('seo', $seo);			
	}
	
	
}