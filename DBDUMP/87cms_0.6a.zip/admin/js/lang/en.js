function lang(str){
	var l = {
		'Maxlength' : 'Maxlength',
		'Attributes list' : 'Attributes list',
		'Extensions (empty = no filter)' : 'Extensions (empty = no filter)',
		'Number of file (0 = no limit)' : 'Number of file (0 = no limit)',
		'Thumbs size' : 'Thumbs size',
		'Medium size' : 'Medium size',
		'Large size' : 'Large size'	
		
	};
	return l[str];
}