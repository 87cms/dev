<?php
$smarty->template_dir = 'theme/';

require_once('classes/FrontController.php');
?>