<?php

class EntityModelField extends EntityModelFieldCore {

	
}