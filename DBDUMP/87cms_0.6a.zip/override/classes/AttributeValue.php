<?php

class AttributeValue extends AttributeValueCore { 

}
