<?php /* Smarty version Smarty-3.1.11, created on 2013-09-09 17:10:40
         compiled from "template/sidebar.html" */ ?>
<?php /*%%SmartyHeaderCode:1281734848522de4f0cacca1-53431936%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'cbdc45f8010ab2b137d5fb5632c17943b3607efc' => 
    array (
      0 => 'template/sidebar.html',
      1 => 1378395984,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1281734848522de4f0cacca1-53431936',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'menu' => 0,
    'entity' => 0,
    'user' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.11',
  'unifunc' => 'content_522de4f0d9e071_69898389',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_522de4f0d9e071_69898389')) {function content_522de4f0d9e071_69898389($_smarty_tpl) {?><?php if (!is_callable('smarty_function_l')) include '/var/www/Sites Web Clients/Sites Web MisterHarry/Gandi/mhweb/bourgogne-vigne-verre.com/validation/tools/smarty/plugins/function.l.php';
?><div id="sidebar">
	
    <div id="logo">
       <a href="/admin"><img src="images/logo.png" width="50" /></a>
	</div>
    	
    <ul>
    	<?php  $_smarty_tpl->tpl_vars['entity'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['entity']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['menu']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['entity']->key => $_smarty_tpl->tpl_vars['entity']->value){
$_smarty_tpl->tpl_vars['entity']->_loop = true;
?>
       	 	<li><a href="index.php?p=entity&id_entity_model=<?php echo $_smarty_tpl->tpl_vars['entity']->value['id_entity_model'];?>
" <?php if ($_smarty_tpl->tpl_vars['entity']->value['id_entity_model']==$_GET['id_entity_model']){?>class="active"<?php }?>><?php echo $_smarty_tpl->tpl_vars['entity']->value['name'];?>
</a></li>
        <?php } ?>
    </ul>
	
    <ul>
    	<li><a href="index.php?p=contact" <?php if ($_GET['p']=='contact'){?>class="active"<?php }?>><?php echo smarty_function_l(array('s'=>'Contact form'),$_smarty_tpl);?>
</a></li>
    </ul>
    
    <?php if ($_smarty_tpl->tpl_vars['user']->value->is_admin){?>
    <ul>
    	<li><a href="index.php?p=entityModel" <?php if ($_GET['p']=='entityModel'){?>class="active"<?php }?>><?php echo smarty_function_l(array('s'=>'Models'),$_smarty_tpl);?>
</a></li>
        <li><a href="index.php?p=attribute" <?php if ($_GET['p']=='attribute'){?>class="active"<?php }?>><?php echo smarty_function_l(array('s'=>'Attribute'),$_smarty_tpl);?>
</a></li>
        <li><a href="index.php?p=settings" <?php if ($_GET['p']=='settings'){?>class="active"<?php }?>><?php echo smarty_function_l(array('s'=>'Settings'),$_smarty_tpl);?>
</a></li>
        <li><a href="index.php?p=modules" <?php if ($_GET['p']=='modules'){?>class="active"<?php }?>><?php echo smarty_function_l(array('s'=>'Modules'),$_smarty_tpl);?>
</a></li>
        <li><a href="index.php?p=users" <?php if ($_GET['p']=='users'){?>class="active"<?php }?>><?php echo smarty_function_l(array('s'=>'Users'),$_smarty_tpl);?>
</a></li>
        <li><a href="index.php?p=translation" <?php if ($_GET['p']=='translation'){?>class="active"<?php }?>><?php echo smarty_function_l(array('s'=>'Translation'),$_smarty_tpl);?>
</a></li>        
    </ul>
    <?php }?>
    
    
    <ul style="display:none">
    	<li><a href="#"><?php echo smarty_function_l(array('s'=>'Help'),$_smarty_tpl);?>
</a></li>
        <li><a href="#">87CMS</a></li>
    </ul>

</div>


<div id="front_header">

	<div class="links">
    	<a href="index.php?logout=1"><img src="images/iconic/white/x_alt_12x12.png" /> &nbsp;<?php echo smarty_function_l(array('s'=>'Log out'),$_smarty_tpl);?>
</a>
        <a href="http://www.google.com/analytics/‎"><img src="images/iconic/white/chart_12x12.png" /> &nbsp;<?php echo smarty_function_l(array('s'=>'Google Analytics'),$_smarty_tpl);?>
</a> 
    </div>
    <div id="search_form" style="display:none">
    	<form>
        	<input type="text" name="search" value="" placeholder="<?php echo smarty_function_l(array('s'=>'Search'),$_smarty_tpl);?>
 ..." class="text" /> <input type="submit" value="<?php echo smarty_function_l(array('s'=>'Search'),$_smarty_tpl);?>
" name="submitSearch" class="submitForm" />
        </form>
    </div>
</div><?php }} ?>