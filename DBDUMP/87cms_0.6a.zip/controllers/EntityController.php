<?php

class EntityControllerCore extends FrontController {
	
	protected $entity;
	protected $entity_model;
	protected $id_current_entity;
	
	/**
	* Run the entity controller. 
	* First we check if the entity exists, and if it's not a draft.
	* Then we check if a specific class or controller exists. 
	* In deed you can add a specific class or controller per Slug. You have to add a process() method in your specific controller
	* If yes the display process will be executed the specific controller.
	* @param Int $id Entity's ID
	*/	
	public function run($id=0){
		
		$this->entity = new Entity($id);
		
		$this->entity->link_rewrite = Link::getEntityLink($this->entity->id_entity, $this->cookie->id_lang);
		
		if( $this->entity->id_entity && $this->entity->state !== 'draft' ){
			
			$this->id_current_entity = $this->entity->id_entity;
			
			// get entity slug
			$this->entity_model = new EntityModel( $this->entity->id_entity_model );
			$slug = $this->entity_model->slug;
			
			$classDir = _ABSOLUTE_PATH_.'/override/classes/';
			$controllerDir = _ABSOLUTE_PATH_.'/override/controllers/';
			
			if( file_exists($classDir.$slug.'.php') )
				require_once($classDir.$slug);
			
			if( file_exists($controllerDir.$slug.'Controller.php') ){
				require_once($controllerDir.$slug);
				$controllerName = $slug.'Controller';
				if( method_exists($controllerName, 'process') ){
					$newObject = new $controllerName();
					$newObject->process();	
				}				
			}
			else
				$this->process();
			
		}else
			$this->error404(1);	
			
	}
	
	public function process(){
		
		
		if( $this->entity_model->hierarchic == 1 ){
			
			$p = (int)Tools::getValue('p');
			$n = (int)Tools::getValue('n');
			$orderway = (int)Tools::getValue('orderway');
			$orderby = (int)Tools::getValue('orderby');
			
			$this->entity->childrens = $this->entity->getChildren($this->cookie->id_lang, 0, 1000, '');

			$attached_entities = $this->entity->getEntitiesAttachedToModel( $this->cookie->id_lang, 0, 1000, '' );
			
			$attached_entities_slug = $this->entity->getEntitySlugAttachedToModel();
			
			if( $attached_entities_slug )
				$this->entity->$attached_entities_slug = $attached_entities;
							
		}
		
		$fields = $this->entity->getData($this->cookie->id_lang);
		$this->entity->fields = $fields;
		
		if( $this->entity_model->hierarchic == 0 ){
			foreach( $this->entity->fields as &$field ){
				
				if( $field['type'] == "linkedEntities" ){
					
					$id_entities = explode(',' , $field['raw_value']);
					$entities = array();
					foreach( $id_entities as $id_entity ){
						$entity = new Entity( $id_entity );
						$entity->fields = $entity->getData($this->cookie->id_lang);
						array_push($entities, $entity);
					}
					$field = $entities;
										
				}
			}
		}
		//var_dump($this->entity->fields);
		
		$b = $this->entity->getBreadcrumb('',$this->cookie->id_lang); 
		$this->entity->breadcrumb = array_reverse($this->entity->breadcrumb);
		
		
		// Add in view the active state for link
		// If you want to add this state to an link, simply add class "entity + ID" or "entityModel + ID"
		// For ex : entity87 or entityModel13
		$active_entity = $this->entity->breadcrumb;
		array_push($active_entity, array(
			'id_entity' => $this->entity->id_entity,
			'id_entity_model' => $this->entity->id_entity_model
		));
		
		
		$this->smarty->assign(array(
			$this->entity->slug => $this->entity,
			'active_entity' => $active_entity
		));
				
		$this->getSEO();
		$this->display();
			
	}
	
	
	
	
	
	/**
	* The classic display method
	*/
	public function display(){
		$tpls = $this->entity->getTemplates();
		$this->sendTemplatesToSmarty( $tpls );		
	}
	
	/**
	* Set SEO elements as meta elements, or canonical
	* TODO : canonical
	*/
	public function getSEO(){
		$seo = Db::getInstance()->getRow('
			SELECT link_rewrite, meta_title, meta_keywords, meta_description FROM '._DB_PREFIX_.'entity_lang 
			WHERE id_lang='.(int)$this->cookie->id_lang.' AND id_entity='.(int)$this->entity->id_entity);
		$this->smarty->assign('seo', $seo);			
		
	}
	
	
}