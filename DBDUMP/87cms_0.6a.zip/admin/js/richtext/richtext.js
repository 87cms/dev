(function($) {

	var self;
	var container;
	var container_width = 0;
	
	richText.prototype.initialize = function(id_point, lat, lng, drive,callback_back_button) {
	
	}
	
	richText.prototype.addLine = function(){
		var line = $('<div></div>').addClass('line');
		container.append('<div class="line"></div>');
		self.attachLinesClickHandler();	
	}
	
	richText.prototype.addColumn = function(){
		var column = $('<div></div>').addClass('column');
		
		// Clear hack
		container.children('.selectedLine').children('.clear').remove();
		
		container.children('.selectedLine').append(column);
		
		container.children('.selectedLine').append('<div class="clear"></div>');
		
		self.setColumnsWidth();
		self.attachColumnsClickHandler();
	}
	
	richText.prototype.setColumnsWidth = function(){
		var nb_child = container.children('.selectedLine').children('.column').length;
		
		var columnPaddingLeft = parseInt($('.column').css('padding-left').replace('px',''));
		var columnPaddingRight = parseInt($('.column').css('padding-right').replace('px',''));
		
		var width = Math.round( (container_width/nb_child) - columnPaddingLeft - columnPaddingRight );
		container.children('.selectedLine').children('.column').css('width', width + 'px');
		
		container.children('.selectedLine').children('.column').removeClass('last');
		container.children('.selectedLine').children('.column').removeClass('first');
		container.children('.selectedLine').children('.column:last').addClass('last');
		container.children('.selectedLine').children('.column:first').addClass('first');
		
		self.attachColumnsClickHandler();
	}
	
	richText.prototype.attachColumnsClickHandler = function(){
		container.children('.selectedLine').children('.column').each( function(){
			$(this).off().on('click', function(){				
				
				// Reset line event 
				self.attachLinesClickHandler();
				container.children('.selectedLine').off();
				
				container.children('.selectedLine').children('.column').removeClass('selectedColumn');				
				var width = $(this).width;
				$(this).css('width', (width-2) + 'px')
				$(this).addClass('selectedColumn');
				
				$('#cmd_column #column_size').text( $(this).outerWidth() + 'px' );
				
				var line_position = $(this).offset();
				$('#cmd_column').css({
					'top' : line_position.top-16 + 'px',
					'left' : (line_position.left + 5) + 'px',
					'display' : 'block'
				});
				
				
				if( container.children('.selectedLine').children('.column').length > 1 ){
					
					var leftBrother = $(".selectedColumn").prev('.column');
					var rightBrother = $(".selectedColumn").next('.column');
					var leftBrotherWidth = leftBrother.width();
					var rightBrotherWidth = rightBrother.width();
					
					var handles = 'e, w';
					if( $(".selectedColumn").hasClass('first') )
						handles = 'e';
					else if( $(".selectedColumn").hasClass('last') ) 
						handles = 'w';
					
					$('.ui-resizable').each( function(){
						$(this).resizable('destroy');
					});
						
					$( ".selectedColumn" ).resizable({
						minWidth: 150,
						handles: handles,
						resize : function(event, ui){
							
							// left	
							if( ui.position.left < 0 ){
								console.log(ui.position.left)
								var w = leftBrotherWidth+ui.position.left;
								leftBrother.width( w );
								$(".selectedColumn").css('left','0');
								
							}
							else if( ui.position.left == 0 && ui.originalSize.width > $(this).width() ){
									
								var w = rightBrotherWidth+(ui.originalSize.width-$(this).width());
								rightBrother.width( w );
								$(".selectedColumn").css('left','0');
								
							}
							// right
							else if( ui.position.left > 0 ) {
								
								var w = leftBrotherWidth+ui.position.left;
								leftBrother.width( w );
								$(".selectedColumn").css('left','0');
								
							}
							else if( ui.position.left == 0 && ui.originalSize.width < $(this).width() ) {
								
								var w = rightBrotherWidth+(ui.originalSize.width-$(this).width());
								rightBrother.width( w );
								$(".selectedColumn").css('left','0');
								
							}
							
							$('#cmd_column #column_size').text( $(this).outerWidth() + 'px' );
							
						}
					});					
				}
			});
		});
	}
	
	richText.prototype.attachLinesClickHandler = function(){
		$('#cmd_column').hide();
		container.children('.line').each( function(){
			$(this).off().on('click', function(){				
				
				$('#cmd_column').hide();
				$('.selectedColumn').removeClass('selectedColumn');
				
				container.children('.line').removeClass('selectedLine');				
				$(this).addClass('selectedLine');
				
				var line_position = $(this).offset();
				$('#cmd_line').css({
					'top' : line_position.top + 'px',
					'left' : (line_position.left-$('#cmd_line').width()) + 'px',
					'display' : 'block'
				});
				
			});
		});
	}
	
	richText.prototype.initElements = function(){
		$('#elementsList li').each( function(){
			var elementName = $(this).attr('data-name');
			$(this).on('click', function(){
				var selectedColumn = $('#richtext .selectedColumn');
				if( selectedColumn )
					eval('$.RT' + elementName + '();');
			});

		});		
	}
	
	richText.prototype.emptyColumn = function(){
		var selectedColumn = $('#richtext .selectedColumn');
		if( confirm(_MESSAGE_EMPTY_COLUMN_) )
			selectedColumn.html('');
	}
	
	richText.prototype.deleteColumn = function(){
		var selectedColumn = $('#richtext .selectedColumn');
		if( confirm(_MESSAGE_DELETE_COLUMN_) ){
			$('#cmd_column').hide();
			selectedColumn.remove();
			self.setColumnsWidth();	
		}
	}
	
	richText.prototype.deleteLine = function(){
		var selectedLine = $('#richtext .selectedLine');
		if( confirm(_MESSAGE_DELETE_COLUMN_) ){
			selectedLine.remove();	
		}
	}
	
	richText.prototype.setCmdEvents = function(){
		$('#cmd_add_line').on( 'click', function(){ self.addLine(); return false; } );
		
		$('#cmd_add_column').on( 'click', function(){ self.addColumn(); return false;  } );	
		$('#cmd_delete_line').on( 'click', function(){ self.deleteLine(); return false;  } );	
		
		$('#cmd_set_column_width').on( 'click', function(){ self.setColumnWidth(); return false;  } );	
		$('#cmd_empty_column').on( 'click', function(){ self.emptyColumn(); return false;  } );	
		$('#cmd_delete_column').on( 'click', function(){ self.deleteColumn(); return false;  } );
		
		$('#column_size').on( 'click', function(){ return false;  } );		
	}
	
	richText.prototype.save = function(){
		// 1. Parse document = 1 column = 1 element
		// 2. Construct array
		// 3. Array to JSON
		// 4. Query	
	}
	
	function richText() {
		self = this;
		
		container = $("#richtext");
		container_width = container.width();		
		container.css('width', container_width+2);
		
		self.setCmdEvents();		
		self.initElements();
		self.attachLinesClickHandler();
		self.attachColumnsClickHandler();
	}
	
	$.fn.richText = function () {
		
		richText_object = new richText();
	}
	

 })( jQuery );
 
