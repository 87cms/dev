<?php

class Module extends ModuleCore {
	

	
}
