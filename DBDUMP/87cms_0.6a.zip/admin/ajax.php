<?php

class AjaxController extends AdminController {
	
	
	public function start(){
			
		/**
		* Mediabox
		*/
		if( Tools::getSuperglobal('mediabox') && Tools::getSuperglobal('action') == "getDirectoryContent" ){	
			$mediabox = new Mediabox(); 
			$_SESSION['id_current_directory'] = (int)Tools::getSuperglobal('id_directory');
			echo json_encode( $mediabox->getDirectoryContent( (int)Tools::getSuperglobal('id_directory') ));
		}
		
		elseif( Tools::getSuperglobal('mediabox') && Tools::getSuperglobal('action') == "addDirectory" ){	
			$mediabox = new Mediabox();
			$data['dirname'] = Tools::getSuperglobal('directory_name');
			$data['id_parent'] = Tools::getSuperglobal('id_parent');
			return $mediabox->createDirectory( $data );
		}
		
		elseif( Tools::getSuperglobal('mediabox') && Tools::getSuperglobal('action') == "deleteFile" ){	
			$mediabox = new Mediabox();
			$mediabox->deleteMedia( (int)Tools::getSuperglobal('id_media') );
		}
		
		elseif( Tools::getSuperglobal('mediabox') && Tools::getSuperglobal('action') == "deleteFolder" ){	
			$mediabox = new Mediabox();
			$mediabox->deleteDirectory( (int)Tools::getSuperglobal('id_directory') );
		}
		
		elseif(  Tools::getSuperglobal('mediabox') && Tools::getSuperglobal('action') == "updateDirectoryName" ){	
			$mediadir = new MediaboxDir( Tools::getSuperglobal('id_directory') );
			if( $mediadir->id_directory > 0 ){
				$mediadir->dirname = Tools::getSuperglobal('name');
				$mediadir->update();
			}
		}
		/*
		END Mediabox
		*/
		
		
		
		elseif( Tools::getSuperglobal('action') == "getAttributesList" ){	
			echo json_encode( Attribute::getAttributesList($this->cookie->id_lang) );		
		}
		
		elseif( Tools::getSuperglobal('action') == "addEntityModel" ){
			$data = json_decode(Tools::getSuperglobal('data'));
			$entity_model = new EntityModel( $data->id_entity_model );
			$entity_model->addModel($data);
		}
		
		elseif( Tools::getSuperglobal('action') == "addEntity" ){
			$data = json_decode(Tools::getSuperglobal('data'));
			$entity = new Entity( $data->id_entity );
			$entity->addEntity($data);
		}
		
		elseif( Tools::getSuperglobal('action') == "getModelsList" ){
			echo json_encode(EntityModel::getModels());
		}
		
		elseif( Tools::getSuperglobal('action') == "getFieldModelsList" ){
			echo json_encode(EntityModelField::getFieldModelsList( Tools::getSuperglobal('id_entity_model'), Tools::getSuperGlobal('field_type') ));
		}

	}

}

?>