<?php

class User extends UserCore {
	
	
	
}