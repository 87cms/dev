<?php

define("TMP", "tmp/"); // Deprecated
define("_TMP_DIR_", "tmp/");
define("_THEME_DIR_", _ABSOLUTE_PATH_.'/theme' );
define("_MEDIAS_DIR_", _ABSOLUTE_PATH_.'/medias' );
define("_ADMIN_DIR_", _ABSOLUTE_PATH_.'/admin' );
define("_MODULES_DIR_", _ABSOLUTE_PATH_.'/modules' );
define("_RICHTEXT_DIR_", _ADMIN_DIR_.'/jsrichtext/elements' );

/****/
define("_DOMAIN_", "bourgogne-vigne-verre.com.misterharry.local");
define("SALT", ")zMpVGmc7Zb)wKE:m)3sW9Ize$dG-ebYNXf");