<?php

class HomeControllerCore extends FrontController {
	
	
	public function run(){
		$this->getSEO();
		$templates = Db::getInstance()->getValue('SELECT value FROM '._DB_PREFIX_.'config WHERE name="homepage_template"');
		$this->sendTemplatesToSmarty( $templates );
	
	}
	
	
	public function getSEO(){
		$data = Db::getInstance()->Select('
			SELECT name,value FROM '._DB_PREFIX_.'config_lang 
			WHERE 
				( name="meta_description" 
				OR name="meta_title" 
				OR name="meta_keywords" )
				AND id_lang='.(int)$this->cookie->id_lang);
		$seo = array();
		foreach( $data as $d )
			$seo[ $d['name'] ] = $d['value'];
		
		$this->smarty->assign('seo', $seo);		
	}
	
	
}