<?php

class FrontControllerCore extends Core {
	
	private $modulesList = array();
	private $actionsList = array();
	private $controllersList = array();
	
	private $css = array();
	
	private $js = array();
	
	private $error404 = true;
	
	//private static $defaultActions = array('Head', 'Header', 'Sidebar', 'Footer');
	
	function __construct(){
		
		global $smarty, $cookie;
		$this->smarty = $smarty;
		
		$this->cookie = new Cookie();
		
		$this->autoRedirect();
		
		$this->cookie->id_lang = $this->getLang( $this->cookie );
		$cookie = $this->cookie;		
		
	}	
	
	public function	run(){
		$this->loadClasses();
		$this->loadControllers(); 
		//$this->getScripts();
		$this->processController();
		$this->router();
		$this->postProcessController();
	}

	
	public function router(){
		
		$this->importLang();
		
		$this->smarty->assign('id_lang', $this->cookie->id_lang);
		$this->smarty->assign('lang_code', Lang::getLangCode($this->cookie->id_lang));

		if( (int)Tools::getSuperglobal('id_entity') ){
			$eId = (int)Tools::getSuperglobal('id_entity');
			$entityController = new EntityController();
			$entityController->run($eId);
		}
		
		elseif( Tools::getSuperglobal('entity_link_rewrite') ){
			
			$mId = (int)EntityModel::getModelIdFromSlug( Tools::getSuperglobal('entity_link_rewrite'), $this->cookie->id_lang );
			$modelController = new EntityModelController();
			$modelController->run($mId);
			
		}
		elseif(Tools::getSuperglobal('page')){
			
			if(Tools::getSuperglobal('page') == "contact"){
				$contact = new ContactController();
				$contact->run();
			}else{
				$this->error404();
				$this->getHomepage();
			}
		}
		elseif( Tools::getSuperglobal('iso_lang') ){
			
			// static pages
			
			// check plugin
			
			// Home page
			$this->getHomepage();
			$this->error404 = false;

		}else{
			$this->getHomepage();
			//$this->error404();
		}
	}
	
	
	/**
	* Call overrided Class placed in "override" folder
	*/	
	private function loadClasses(){
		
		/*$classesDirectory = _ABSOLUTE_PATH_.'/classes';
		$dir = opendir($classesDirectory);
		while( $file = readdir($dir) ) {    
			if($file !== "." && $file !== ".." )
				require_once($classesDirectory.'/'.$file);

		}*/
		require_once("classes/Lang.php");
		require_once("classes/FrontController.php");
		require_once("classes/Module.php");
		require_once("classes/Hook.php");
		require_once("classes/Db.php");
		require_once("classes/Core.php");
		require_once("classes/AttributeValue.php");
		require_once("classes/Attribute.php");
		require_once("classes/EntityField.php");
		require_once("classes/EntityModel.php");
		require_once("classes/Richtext.php");
		require_once("classes/SimpleImage.php");
		require_once("classes/Widget.php");
		require_once("classes/Mysql.php");
		require_once("classes/Tools.php");
		require_once("classes/Entity.php");
		require_once("classes/EntityModelField.php");
		require_once("classes/Error.php");
		require_once("classes/Cookie.php");
		require_once("classes/Link.php");
		require_once("classes/User.php");
		require_once("classes/Contact.php");
		
		$overrideDirectory = _ABSOLUTE_PATH_.'/override/classes';
		$dir = opendir($overrideDirectory);
		while( $file = readdir($dir) ) {    
			if($file !== "." && $file !== ".." )
				require_once($overrideDirectory.'/'.$file);	
		}
		
	}
	
	/**
	* Call overrided Controllers placed in "override" folder
	*/
	private function loadControllers(){
		
		$controllersDirectory = _ABSOLUTE_PATH_.'/controllers';
		$dir = opendir($controllersDirectory);
		while( $file = readdir($dir) ) {    
			if($file !== "." && $file !== ".." )
				require_once($controllersDirectory.'/'.$file);

		}
		
		$overrideDirectory = _ABSOLUTE_PATH_.'/override/controllers';
		$dir = opendir($overrideDirectory);
		while( $file = readdir($dir) ) {    
			if($file !== "." && $file !== ".." )
				require_once($overrideDirectory.'/'.$file);	
		}
		
	}
	
	
	/**
	* Automatically link CSS into the header
	*/	
	private function includeCss() {
		foreach( $this->modulesList as $module ){
			$css = 'modules/'.$module['name'].'/'.$module['name'].'.css' ;
			if( is_file($css) )
				$this->css[] = $css;
		}		
	}
	
	/**
	* Automatically link JS into the header
	*/
	private function includeJs() {
		foreach( $this->modulesList as $module ){
			$css = 'modules/'.$module['name'].'/'.$module['name'].'.js' ;
			if( is_file($js) )
				$this->js[] = $js;
		}	
	}
	
	
	/**
	* Get all scripts attached to modules and send to the view
	*/
	private function getScripts(){
		$this->includeCss();
		$this->includeJs();
		$this->smarty->assign('js', $js);
		$this->smarty->assign('css', $css);
		$this->smarty->assign('token', Tools::getToken());
	}
	
	
	
	/**
	* Assign default actions content
	*/
	/*private function defaultActions(){
		$actionOUT = array();
		
		foreach( self::$defaultActions as $action ){
			
			$modulesList = Modules::getModulesAttachedToAction($action);
			foreach( $modulesList as $module ){
				
				$newObject = new $module['className']();
				$actionName = 'action'.$action;
				
				if( method_exists($newObject, $actionName) ){
					$actionOUT[ $action ] .= $newObject->$actionName();
					
				}
				
			}		
		}
		
		$this->smarty->assign( array(
			'ACTION_HEAD' => $actionOUT['head'],
			'ACTION_HEADER' => $actionOUT['header'],
			'ACTION_SIDEBAR' => $actionOUT['sidebar'],
			'ACTION_FOOTER' => $actionOUT['footer']
		));
		
	}*/
	
	/**
	* Display the 404 error page
	*/
	public function error404($force=0){
		if( $this->error404 || $force ){
			header("HTTP/1.0 404 Not Found");
			$this->smarty->display('header.html');
			$this->smarty->display('404.html');
			$this->smarty->display('footer.html');
		}
	}
	
	
	/**
	* Display the home page with the homeController
	*/
	public function getHomepage(){
		require_once(_ABSOLUTE_PATH_.'/controllers/HomeController.php');
		$homeController = new homeController();
		$homeController->run();	
	}
	
	public function sendTemplatesToSmarty($string){
		$string = str_replace(' ', '', $string);
		$array = explode(',', $string);
		
		$module = new Module();
		$module_content = $module->getDisplay($array);
		
		if( $module_content ){
			foreach( $module_content as $hook => $content ){
				$this->smarty->assign($hook, $content);
			}
		}
		
		foreach( $array as $tpl ){
			$this->smarty->display( $tpl );
		}
	}
	
	
	public function processController(){
		$google_analytics_ID = Db::getInstance()->getValue('SELECT value FROM '._DB_PREFIX_.'config WHERE name="google_analytics_ID" ');
		
		$this->smarty->assign(array(
			'google_analytics_ID' => $google_analytics_ID
		));
	}
	
	public function postProcessController(){
		
	}
	
	private function autoRedirect(){
		
		$default_lang = Db::getInstance()->getRow('SELECT id_lang, code FROM '._DB_PREFIX_.'lang WHERE defaultlang=1');
		$redirect = false;
		
		if( empty($_GET) && empty($_POST) ){
			if( !isset($this->cookie->id_lang) ){
				
				$lang_code = $default_lang['code'];	
				$this->cookie->id_lang = $default_lang['id_lang'];
				$redirect = true;
				
			}
			else{
				$lang = Db::getInstance()->getRow('SELECT id_lang, code FROM '._DB_PREFIX_.'lang WHERE id_lang='.(int)$this->cookie->id_lang);
				
				if( !$lang ){
					$lang_code = $default_lang['code'];	
					$this->cookie->id_lang = $default_lang['id_lang'];
					$redirect = true;	
				}
				else{
					$lang_code = $lang['code'];	
					$this->cookie->id_lang = $lang['id_lang'];	
					$redirect = true;
				}
				
			}
		}
		elseif( Tools::getSuperglobal('iso_lang') ){
			$lang = Db::getInstance()->getRow('SELECT id_lang, code FROM '._DB_PREFIX_.'lang WHERE code="'.Tools::cleanSQL(Tools::getSuperglobal('iso_lang')).'"');
			
			if( !$lang ){
				$lang_code = $default_lang['code'];	
				$this->cookie->id_lang = $default_lang['id_lang'];
				$redirect = true;	
			}else
				$this->cookie->id_lang = $lang['id_lang'];
		
		}
		
		if( $redirect ){
			header("HTTP/1.1 301 Moved Permanently");
			header('Location: http://'._DOMAIN_.'/'.$lang_code.'/');
		}
		
	}
	
	private function importLang(){
		$lang_code = Lang::getLangCode($this->cookie->id_lang);
		if(is_file('lang/'.$lang_code.'.php')) 
			include('lang/'.$lang_code.'.php');
		
	}
	
}

