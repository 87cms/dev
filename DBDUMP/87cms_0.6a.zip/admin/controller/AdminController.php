<?php

class AdminController extends Core {

	protected $smarty;
	protected $cookie;
	
	public $action;
	protected $user;
	
	function __construct(){
		
		global $smarty, $cookie;
		$this->smarty = $smarty;

		$this->cookie = new Cookie();
		$this->cookie->id_lang = $this->getLang( $this->cookie );
		$cookie = $this->cookie;
		
		$this->loadElements();		
	}
	
	
	
	public function start(){
		
		Tools::setToken();
		$this->smarty->assign('token', Tools::getToken());
		$this->sendLangToSmarty();
		
		$page = Tools::getSuperglobal('p');
		
		if( Tools::getSuperglobal('logout') == 1 ){
			$this->cookie->destroy();
			Tools::redirect('/admin/index.php?p=login'); 
		}
	
		
		// 1. User is logged ?
		$this->user = new User();
		
		$this->user->authUser($this->cookie->emailp, $this->cookie->hashp);
		
		if( Tools::getSuperglobal('submitLogin') ){
			$this->user->authUser(Tools::getSuperglobal('login_email'), '', Tools::getSuperglobal('login_password'));
			if( $this->user->is_logged ){
				$this->cookie->emailp = $this->user->email; 
				$this->cookie->hashp = hash('sha256', $this->user->password);	
				Tools::redirect('/admin/index.php');		
			}
		}
		
		if( !$this->user->is_logged && $page !== "login" )
			Tools::redirect('/admin/index.php?p=login'); 
			
		
		
		// 2. Menu
		$menu = $this->getMenu();
		$this->smarty->assign(array(
			'menu' => $menu,
			'user' => $this->user			
		));
		
		
		if( !empty($page) /*&& self::validatePage($page)*/ ){
			
			if( $page == "login" ){
				$this->smarty->display('login.html');
				die();	
			}
			
			$this->smarty->display('head.html');
			$this->smarty->display('sidebar.html');

			$controllerName = ucfirst($page).'Controller';
			
			if( file_exists('controller/'.$controllerName.'.php') ){
				require_once('controller/'.$controllerName.'.php');
				$controller = new $controllerName();
				$controller->run($this->user);
			}
			
			$this->smarty->display('footer.html');
		
		}else{
			
			$this->displayHome();
		
		}
	
	}
	
	private function sendLangToSmarty(){
		$languages = Lang::getLanguages();
		$this->smarty->assign('LANG', Lang::getLangCode($this->cookie->id_lang) );
		$this->smarty->assign('languages', $languages);	
	}
	
	private function displayHome(){
		
		// Google Analytics part
		// https://developers.google.com/analytics/solutions/articles/hello-analytics-api
		//
		/*require_once 'tools/gapi/src/Google_Client.php';
		require_once 'tools/gapi/src/contrib/Google_AnalyticsService.php';
		
		$client = new Google_Client();
		$client->setApplicationName('BVG');
		
		// Visit //code.google.com/apis/console?api=analytics to generate your
		// client id, client secret, and to register your redirect uri.
		$client->setClientId('342019279887-rl3e9r3rue7h7hp8nbe7sg2du6ru97ut.apps.googleusercontent.com');
		$client->setClientSecret('6kKa9WVzAUvGJwV7oIybKO5x');
		$client->setRedirectUri('https://www.bvgsa.com/oauth2callback');
		$client->setDeveloperKey('AIzaSyBSAcfWe5d-qELWsuL0FQ1g3qRqFt6hLjY');
		$client->setScopes(array('https://www.googleapis.com/auth/analytics.readonly'));
		
		// Magic. Returns objects from the Analytics Service instead of associative arrays.
		$client->setUseObjects(true);
			*/	
		// End GA
		
		$this->smarty->display('head.html');
		$this->smarty->display('sidebar.html');
		$this->smarty->display('home.html');
		$this->smarty->display('footer.html');
	}
	
	private static function validatePage(){
		return true;
	}
	
	private function getMenu(){
		$results = array();
		$sql =	'SELECT * FROM '._DB_PREFIX_.'model_entity M
		LEFT JOIN '._DB_PREFIX_.'model_entity_lang L ON M.id_entity_model = L.id_entity_model
		WHERE L.id_lang ='.(int)$this->cookie->id_lang.'
		AND M.deleted=0
		ORDER BY hierarchic DESC';
		$elements = Db::getInstance()->Select($sql);
		
		if( $this->user->is_admin )
			return $elements;
		
		else {
			$array = array();
			for($i=0;$i<count($elements);$i++){
				if( $this->user->userHasPermission($elements[$i]['id_entity_model'], -1) )
					array_push( $array, $elements[$i] );
			}
			return $array;
		}
		
	}
	
	private function loadElements(){
		
		require_once("../classes/Lang.php");
		require_once("../classes/FrontController.php");
		require_once("../classes/Module.php");
		require_once("../classes/Hook.php");
		require_once("../classes/Db.php");
		require_once("../classes/Core.php");
		require_once("../classes/MediaboxFile.php");
		require_once("../classes/AttributeValue.php");
		require_once("../classes/Attribute.php");
		require_once("../classes/EntityField.php");
		require_once("../classes/EntityModel.php");
		require_once("../classes/Richtext.php");
		require_once("../classes/MediaboxDir.php");
		require_once("../classes/SimpleImage.php");
		require_once("../classes/Mediabox.php");
		require_once("../classes/Widget.php");
		require_once("../classes/Mysql.php");
		require_once("../classes/Tools.php");
		require_once("../classes/Entity.php");
		require_once("../classes/EntityModelField.php");
		require_once("../classes/Error.php");
		require_once("../classes/Cookie.php");
		require_once("../classes/Link.php");
		require_once("../classes/Upload.php");
		require_once("../classes/User.php");
		require_once("../classes/Contact.php");
		
		/*$classesDirectory = '../classes';
		$dir = opendir($classesDirectory);
		while( $file = readdir($dir) ) {    
			if($file !== "." && $file !== ".." ){
				//echo 'require_once("'.$classesDirectory.'/'.$file.'")<br >';
				//require_once($classesDirectory.'/'.$file);
			}

		}*/
		
		$overrideDirectory = '../override/classes';
		$dir = opendir($overrideDirectory);
		while( $file = readdir($dir) ) {    
			if($file !== "." && $file !== ".." )
				require_once($overrideDirectory.'/'.$file);	
		}
	
	}
	

}




