<?php

class EntityModel extends EntityModelCore {

		
}