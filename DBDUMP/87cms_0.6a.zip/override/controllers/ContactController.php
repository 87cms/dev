<?php

class ContactController extends ContactControllerCore {

	public function sendMessage(){
		
		$st = Tools::getValue('receivers');
		$to = array();
		if(count($st)>0){
			foreach ($st as $key => $id) {
				switch ($id) {
					case 'jpB':
						array_push($to, "antoine@misterharry.fr");
						break;
					case 'pB':
						array_push($to, "antoine@misterharry.fr");
						break;
					case 'bB':
						array_push($to, "antoine@misterharry.fr");
						break;
					case 'gD':
						array_push($to, "antoine@misterharry.fr");
						break;
					case 'gJ':
						array_push($to, "antoine@misterharry.fr");
						break;
					case 'lG':
						array_push($to, "antoine@misterharry.fr");
						break;
					case 'jG':
						array_push($to, "antoine@misterharry.fr");
						break;
					case 'mB':
						array_push($to, "antoine@misterharry.fr");
						break;
					case 'pD':
						array_push($to, "antoine@misterharry.fr");
						break;
					case 'sS':
						array_push($to, "antoine@misterharry.fr");
						break;
					default:
						break;
				}
			}
		}
		
		
		// Sujet
		$subject = 'Demande de contact à partir du site - BVGSA.com';

		// message
		$message = '
		<html>
			<head>
				<title>BVGSA.com</title>
				<style>
					body {
						background-color: #fafafa;
					}
				</style>
			</head>
			<body>';


		$message .= '<p>Prénom : '.Tools::getValue("firstname").'<br>
					Nom : '.Tools::getValue("lastname").'<br>
					Entreprise : '.Tools::getValue("enterprise").'<br />
					Email : '.Tools::getValue("email").'</p>';
		$message .= '<p>Addresse : <br>'.Tools::getValue("address").' - '.Tools::getValue("zip").' '.Tools::getValue("city").' - '.Tools::getValue("country").'</p>';
		$message .= '<p>Téléphone : '.Tools::getValue("tel").'<br>Fax : '.Tools::getValue("fax").'</p>';
		$message .= '<hr>';
		$message .= '<p>'.nl2br(Tools::getValue("message")).'</p>';
		$message .= '<hr>';
		$message .= '<p>Message envoyé depuis votre site internet BVGSA.com</p>';
		$message .= '<a href="mailto: '.Tools::getValue("email").'" title="Envoyer une réponse à l\'adresse '.Tools::getValue("email").'">Pour répondre cliquez ici : '.Tools::getValue("email").'</a>';
			
		$message .= '
			</body>
		</html>
		';
		
		$contact = new Contact();
		$contact->contact_to = implode(',', $to);;
		$contact->subject = $subject;
		$contact->message = $message;
		$contact->contact_from = Tools::getValue("firstname").' '.Tools::getValue("lastname").' : '.Tools::getValue("enterprise").' : '.Tools::getValue("email");
		
			if($message->send()){
				Tools::redirect('/'.Lang::getLangCode($this->cookie->id_lang).'/contact/');
			}else{
				Tools::redirect('/'.Lang::getLangCode($this->cookie->id_lang).'/contact/error');
			}

	}

	
	
}