<?php /* Smarty version Smarty-3.1.11, created on 2013-09-09 17:10:40
         compiled from "template/footer.html" */ ?>
<?php /*%%SmartyHeaderCode:1566998536522de4f0ed35f9-27703857%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'edf5c389830776f50324212d76ef6f680f1e7d9b' => 
    array (
      0 => 'template/footer.html',
      1 => 1378385846,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1566998536522de4f0ed35f9-27703857',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.11',
  'unifunc' => 'content_522de4f0ed9d46_94999693',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_522de4f0ed9d46_94999693')) {function content_522de4f0ed9d46_94999693($_smarty_tpl) {?><div id="footer" style="clear:both">

</div>

<div id="overlay"> </div>
<div id="overlay_container"> </div>
<!--<?php $_smarty_tpl->smarty->loadPlugin('Smarty_Internal_Debug'); Smarty_Internal_Debug::display_debug($_smarty_tpl); ?>-->

</body>
</html><?php }} ?>