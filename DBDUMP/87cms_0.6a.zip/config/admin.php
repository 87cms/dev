<?php
$smarty->template_dir = 'admin/';

require_once('controller/AdminController.php');
?>