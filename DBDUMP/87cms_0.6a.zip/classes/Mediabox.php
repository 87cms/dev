<?php

class Mediabox extends Core {
	
	public $mimetype;
	
	function __construct($mimetype = NULL){
		$this->mimetype = $mimetype;	
	}

	/**
	* Manage directory
	*/
	public function getDirectoryContent($id_directory){
		$files = array();
		$files['folders'] = MediaboxDir::getDirectories($id_directory);
		$files['files'] = MediaboxFile::getFilesFromDir($id_directory);
		return $files;
	}
	
	public function getDirectoryTree($id_parent){
		$directories = Db::getInstance()->Select('SELECT * FROM '._DB_PREFIX_.'media_directory WHERE id_parent=:id_parent AND deleted=0', array('id_parent' => $di_parent));
		foreach( $directories as &$directory ){
			$directory['children'] = $this->getDirectoryTree( $directory['id_directory'] );
		}
		return $directories;
	}
	
	public function createDirectory($data){
		$directory = new MediaboxDir($data['id_directory']);
		$directory->dirname = $data['dirname'];
		$directory->id_parent = $data['id_parent'];
		if( $data['id_directory'] > 0 )
			$directory->update();	
		else
			$directory->add();
	}
	
	public function updateDirectory($data){
		$this->createDirectory($data);	
	}
	
	public function deleteDirectory($id_directory){
		$directory = new MediaboxDir($id_directory);
		$directory->delete();
	}
	
	
	/**
	* Manage medias
	*/
	public function addMedia($data){
		$media = new MediaboxFile($data['id_media']);
		$media->filename = $data['filename'];
		$media->mimetype = $data['mimetype'];
		$media->path = $data['path'];
		$media->id_directory = $data['id_directory'];
		if( $data['id_media'] > 0 )
			$media->update();	
		else
			$media->add();		
	}
	
	public function updateMedia($data){
		$this->addMedia($data);	
	}
	
	public function deleteMedia($id_media){
		$media = new MediaboxFile($id_media);
		$media->delete();			
	}
	
	
	/**
	* Upload
	* Les images sont stockés dans le dossier medias sous la forme /ANNEE/MOIS/IDIMAGE-SIZE-IMAGENAME
	*
	*/
	public static function getImagesSizes(){
		$sizes = Db::getInstance()->Select('SELECT * FROM '._DB_PREFIX_.'image_size');
		$out = array();
		foreach( $sizes as $size ){
			$out[ $size['name'] ] = array(
				'max_width' => $size['width'],
				'max_height' => $size['height'],
				'jpeg_quality' => 100
			);			
		}
		return $out;
	}

}




?>