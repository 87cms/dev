<?php

class HomeController extends HomeControllerCore {
	
	
	
	
	
}