<?php

class EntityController extends EntityControllerCore {
	
	
	
}