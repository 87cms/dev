<?php /* Smarty version Smarty-3.1.11, created on 2013-09-09 17:10:40
         compiled from "template/attribute_form.html" */ ?>
<?php /*%%SmartyHeaderCode:1676035455522de4f0dbd254-42397023%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ce13490893f7d3f16a939cee86aa4a7788b41576' => 
    array (
      0 => 'template/attribute_form.html',
      1 => 1378738721,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1676035455522de4f0dbd254-42397023',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'attribute' => 0,
    'languages' => 0,
    'value' => 0,
    'token' => 0,
    'variable' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.11',
  'unifunc' => 'content_522de4f0ecadc1_99918392',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_522de4f0ecadc1_99918392')) {function content_522de4f0ecadc1_99918392($_smarty_tpl) {?><?php if (!is_callable('smarty_function_l')) include '/var/www/Sites Web Clients/Sites Web MisterHarry/Gandi/mhweb/bourgogne-vigne-verre.com/validation/tools/smarty/plugins/function.l.php';
?><div id="content">
	<h1><?php echo smarty_function_l(array('s'=>'Edit attribute'),$_smarty_tpl);?>
</h1>
	<p>
    
    </p>
    <div class="form">
    	<h2><?php echo smarty_function_l(array('s'=>'General'),$_smarty_tpl);?>
</h2>
        <form action="index.php?p=attribute" method="post">
        	<div class="form_line">
                <label><?php echo smarty_function_l(array('s'=>'Slug'),$_smarty_tpl);?>
 </label> <input type="text" class="text" name="slug" id="entity_slug" value="<?php echo $_smarty_tpl->tpl_vars['attribute']->value->slug;?>
">
            </div>
            <div class="multilang form_line">
                <label><?php echo smarty_function_l(array('s'=>'Name'),$_smarty_tpl);?>
</label>
                <div class="floatLeft">
                <?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['value']->_loop = false;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
$_smarty_tpl->tpl_vars['value']->_loop = true;
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
                    <p><input type="text" name="name#<?php echo $_smarty_tpl->tpl_vars['value']->value['id_lang'];?>
" class="text" value="<?php echo $_smarty_tpl->tpl_vars['attribute']->value->lang[$_smarty_tpl->tpl_vars['value']->value['id_lang']]['name'];?>
" /> <img src="images/flags/<?php echo $_smarty_tpl->tpl_vars['value']->value['code'];?>
.png" class="flag" /></p>
                <?php } ?>
                </div>
            </div>
            <div class="form_line">
	            <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
" />
                <input type="hidden" name="idAttribute" value="<?php echo $_smarty_tpl->tpl_vars['attribute']->value->id_attribute;?>
" />
                <input type="submit" name="submitAttribute" value="<?php echo smarty_function_l(array('s'=>'Save'),$_smarty_tpl);?>
" class="button submit" />
            </div>
        </form>
    </div>
    
    
    <div class="form">
    	<h2><?php echo smarty_function_l(array('s'=>"Attribute values"),$_smarty_tpl);?>
</h2>
        <form action="index.php?p=attribute&action=form&id_attribute=<?php echo $_smarty_tpl->tpl_vars['attribute']->value->id_attribute;?>
" method="post" id="attribute_values_form">
        <table id="attributes_values_list">
        	<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['value']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['attribute']->value->values; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
$_smarty_tpl->tpl_vars['value']->_loop = true;
?>
            <tr>
	        	<td width="350">
                <?php  $_smarty_tpl->tpl_vars['variable'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['variable']->_loop = false;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['variable']->key => $_smarty_tpl->tpl_vars['variable']->value){
$_smarty_tpl->tpl_vars['variable']->_loop = true;
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['variable']->key;
?>
                    <p><input type="text" name="value#<?php echo $_smarty_tpl->tpl_vars['variable']->value['id_lang'];?>
#<?php echo $_smarty_tpl->tpl_vars['value']->value['id_attribute_value'];?>
" class="text" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['value'][$_smarty_tpl->tpl_vars['variable']->value['id_lang']]['value'];?>
" /> <img src="images/flags/<?php echo $_smarty_tpl->tpl_vars['variable']->value['code'];?>
.png" class="flag" /></p>
                <?php } ?>
                </td>
                <td>
                	<a href="#" class="attribute_value_delete button_delete" data-id="<?php echo $_smarty_tpl->tpl_vars['value']->value['id_attribute_value'];?>
"><?php echo smarty_function_l(array('s'=>"Delete"),$_smarty_tpl);?>
</a>
                </td>
            </tr>
            <?php } ?>
        </table>
        <p>
        	<input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
" />
            <input type="hidden" name="idAttribute" value="<?php echo $_smarty_tpl->tpl_vars['attribute']->value->id_attribute;?>
" />
            <!--<input type="submit" name="addLine" value="<?php echo smarty_function_l(array('s'=>'Add value'),$_smarty_tpl);?>
" class="button" id="addLine" />-->
            <a href="index.php?p=attribute&action=form&id_attribute=<?php echo $_smarty_tpl->tpl_vars['attribute']->value->id_attribute;?>
&addLine=1#addLine" class="button" id="addLine"><?php echo smarty_function_l(array('s'=>'Add value'),$_smarty_tpl);?>
</a>
            <input type="submit" name="submitValues" value="<?php echo smarty_function_l(array('s'=>'Save'),$_smarty_tpl);?>
" class="button submit" />
        </p>
        </form>
    </div>
    
</div>

<script type="text/javascript">
$(document).ready(function(e) {
    $('.attribute_value_delete').each( function(){ 
		$(this).click( function(){
			if( confirm('<?php echo smarty_function_l(array('s'=>"Are you sure ?"),$_smarty_tpl);?>
') ){
				location.href = 'index.php?p=attribute&action=form&deleteAttributeValue=1&id_attribute=<?php echo $_smarty_tpl->tpl_vars['attribute']->value->id_attribute;?>
&id_attribute_value=' + $(this).attr('data-id');	
				return false;
			}
		});
	});
	
	/*$('#addLine').click( function(){
	
		var h = $('#attributes_values_list tr:last').find('input:first').clone();
		
		
		h.each( function(index, item){
			var n = $(item).attr('name');
			$(item).attr('value', '');
			$(item).css('display', 'none');
			$(item).attr('name', n + 'a');
			$('#attribute_values_form').append(item);
		});
		
		return true;
	});*/
	
});
</script><?php }} ?>