<?php

class ContactCore extends Core {
	
	protected $table = "contact";	
	protected $identifier = 'id_contact';
	
	public $contact_to;
	public $subject;
	public $message;
	public $contact_from;	

	public function send(){
		if(	!empty($this->to) ){
			$this->sendEmail();
			$this->add();
		}else{
			return false;
		}
		
	}

	public function sendEmail(){

		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";

		$headers .= 'To: '.$this->to."\r\n";
		$headers .= 'From: BVGSA.com <no-reply@bvgsa.com>' . "\r\n";
		$headers .= 'Cc: '.$to."\r\n";
		
		mail($this->to, $this->subject, $this->message, $headers);
	}

	
	public static function getContacts(){
		return Db::getInstance()->Select('SELECT * FROM '._DB_PREFIX_.'contact ORDER BY id_contact');
	}
	
	
}


