<?php
global $cookie, $smarty;

session_start();

define("_ABSOLUTE_PATH_", getcwd().'/..' );
require_once('../config/constant.php');
require_once('../config/db_settings.php');

define("SQL_DEBUG", true);

require_once('../classes/Error.php');
require_once('../classes/Tools.php');
require_once('../classes/Core.php');
require_once('../classes/Cookie.php');
require_once('../classes/Db.php');
require_once('../classes/Mysql.php');

require_once('controller/AdminController.php');

require_once('../tools/smarty/Smarty.class.php');
$smarty = new Smarty();
$smarty->compile_dir = 'cache';
$smarty->cache_dir = 'cache';
$smarty->config_dir = '../tools/smarty/configs';
$smarty->template_dir = 'template';
$smarty->caching = 0;
$smarty->debugging = false;



if(is_file('lang/fr.php')) 
	include('lang/fr.php');


date_default_timezone_set('Europe/Paris');



if( Tools::getSuperglobal('ajax') ){
	require_once('ajax.php');	
	$ajaxController = new AjaxController();
	$ajaxController->start();
	
}else{
	$adminController = new AdminController();
	$adminController->start();
}

?>