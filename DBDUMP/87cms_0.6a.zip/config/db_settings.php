<?php

define("DBHOST", "localhost");
define("DBNAME", "bvv");
define("DBUSER", "bvv");
define("DBPASSWORD", "dveNc3PRcdi6pN1I2OAp");
define("_DB_PREFIX_", "");
