<?php

class EntityField extends EntityFieldCore {

	
	
}