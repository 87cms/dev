<?php

class Lang extends LangCore {

}

